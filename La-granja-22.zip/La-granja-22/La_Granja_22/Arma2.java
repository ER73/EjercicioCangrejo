import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Arma2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Arma2 extends Actor
{
    /**
     * Act - do whatever the Arma2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        muerteB2();
    }
    
     /**
     * Este metodo se encarga de matar a los bichos2 que toca
     */
    public void muerteB2()
    {
        Nivel2 aux = new Nivel2();
        if(this.isTouching(Bicho2.class))
        {
            this.removeTouching(Bicho2.class);
            aux.bichosMuertos();
            aux.removeObject(this);
        }
    }
}
