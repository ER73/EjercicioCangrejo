import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel2 extends World
{
    private Counter bmuertos;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Nivel2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        bmuertos = new Counter();
        bmuertos.setValue(0);
    }
    
    public void act()
    {
           creaBichos();
           aparecePuntos();
           apareceVida();
           sigNivel();
    }
    
    /**
     * Funcion para incrementar el contador de bichos muertos cuando uno muere
     */
    public void bichosMuertos()
    {
        bmuertos.setValue(bmuertos.getValue()+1);
    }
    
    /**
     * Este metodo crea bichos en un tiempo y espacio aleatorio
     */
    public void creaBichos()
    {
        if(Greenfoot.getRandomNumber(300) == 33)
        {
            addObject(new Bicho2(), Greenfoot.getRandomNumber(600),
                                  Greenfoot.getRandomNumber(400));
        }
    }
    
    /**
     * Funcion para cambiar de mundo cuando se mata al numero adecuado de bichos
     */
    public void sigNivel()
    {
        if(bmuertos.getValue() == 15)
        {
            Greenfoot.setWorld(new Nivel3());
        }
    }
    
    private void prepare()
    {
        Cultivo cultivo = new Cultivo();
        addObject(cultivo,56,92);
        Cultivo cultivo2 = new Cultivo();
        addObject(cultivo2,135,148);
        Cultivo cultivo3 = new Cultivo();
        addObject(cultivo3,230,205);
        Cultivo cultivo4 = new Cultivo();
        addObject(cultivo4,341,246);
        Cultivo cultivo5 = new Cultivo();
        addObject(cultivo5,293,307);
        Cultivo cultivo6 = new Cultivo();
        addObject(cultivo6,293,307);
        Cultivo cultivo8 = new Cultivo();
        addObject(cultivo8,485,255);
        Cultivo cultivo9 = new Cultivo();
        addObject(cultivo9,475,221);
        Cultivo cultivo10 = new Cultivo();
        addObject(cultivo10,376,122);
        cultivo.setLocation(67,41);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(376,122);
        cultivo10.setLocation(278,44);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(135,148);
        cultivo2.setLocation(526,46);
        cultivo3.setLocation(73,157);
        cultivo4.setLocation(278,162);
        cultivo9.setLocation(521,161);
        cultivo6.setLocation(72,276);
        cultivo5.setLocation(291,270);
        cultivo8.setLocation(526,273);
    }
    
    /**
     * Este metodo se encarga de aparecer items que dan puntos aleatoriamente
     */
    public void aparecePuntos()
    {
       if(Greenfoot.getRandomNumber(1000) == 20)
       {
           addObject(new Itempuntos(), getWidth(), 240);
       } 
    }
    
    /**
     * Este metodo se encarga de aparecer items que dan vida aleatoriamente
     */
    public void apareceVida()
    {
       if(Greenfoot.getRandomNumber(5000) == 20)
       {
           addObject(new Itemvida(), getWidth(), 240);
       } 
    }
}
