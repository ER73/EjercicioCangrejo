import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Arma1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Arma1 extends Actor
{
    /**
     * Act - do whatever the Arma1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        muerteB1();
    }
    
    /**
     * Este metodo se encarga de matar a los bichos1 que toca
     */
    public void muerteB1()
    {
        Nivel1 aux = new Nivel1();
        if(this.isTouching(Bicho1.class))
        {
            this.removeTouching(Bicho1.class);
            aux.bichosMuertos();
            aux.removeObject(this);
        }
    }
}
