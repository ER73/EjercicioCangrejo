import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nivel2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel3 extends World
{
    private Counter ctiempo;
    private SimpleTimer tiempo;
    
    /**
     * Constructor for objects of class Nivel2.
     * 
     */
    public Nivel3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        tiempo.mark();
        ctiempo.setValue(90);
        addObject(ctiempo,400,15);
    }
    
    public void act()
    {
           aparecePuntos();
           apareceVida();
           decTiempo();
           creaBichos();
    }
    
    /**
     * Este metodo crea bichos en un tiempo y espacio aleatorio
     */
    public void creaBichos()
    {
        if(Greenfoot.getRandomNumber(300) == 33)
        {
            addObject(new Bicho1(), Greenfoot.getRandomNumber(600),
                                  Greenfoot.getRandomNumber(400));
        }
    }
    
    /**
     * Este metodo se encarga de decrementar el contador del tiempo del nivel
     */
    public void decTiempo()
    {
        if(tiempo.millisElapsed()%100 == 0)
        {
            ctiempo.setValue(ctiempo.getValue()-1);
        }
    }
    
    private void prepare()
    {
        Cultivo cultivo = new Cultivo();
        addObject(cultivo,81,66);
        Cultivo cultivo2 = new Cultivo();
        addObject(cultivo2,256,76);
        Cultivo cultivo3 = new Cultivo();
        addObject(cultivo3,76,206);
        Cultivo cultivo4 = new Cultivo();
        addObject(cultivo4,263,208);
        Cultivo cultivo5 = new Cultivo();
        addObject(cultivo5,493,208);
    }
    
    /**
     * Este metodo se encarga de aparecer items que dan puntos aleatoriamente
     */
    public void aparecePuntos()
    {
       if(Greenfoot.getRandomNumber(1000) == 20)
       {
           addObject(new Itempuntos(), getWidth(), 240);
       } 
    }
    
    /**
     * Este metodo se encarga de aparecer items que dan vida aleatoriamente
     */
    public void apareceVida()
    {
       if(Greenfoot.getRandomNumber(5000) == 20)
       {
           addObject(new Itemvida(), getWidth(), 240);
       } 
    }
}
