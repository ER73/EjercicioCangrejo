import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Maiz here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cultivo extends Actor
{
    private Counter vidaCul;
    
    public Cultivo()
    {
        vidaCul = new Counter();
        vidaCul.setValue(500);
    }
    
    /**
     * Act - do whatever the Maiz wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        vida();
    }
    
    /**
     * Este metodo le quita vida al cultivo si un bicho se lo esta comiendo
     */
    public void vida()
    {
        if(this.isTouching(Bicho1.class) || this.isTouching(Bicho2.class)
                                         || this.isTouching(Bicho3.class))
        {
            vidaCul.setValue((vidaCul.getValue())-1);
        }
    }
    
    /**
     * Este metodo elimina el cultivo si ya se quedo sin vida
     */
    public void muerte1()
    {
        if(vidaCul.getValue() == 0)
        {
            Nivel1 aux = new Nivel1();
            aux.removeObject(this);
        }
    }
    
    /**
     * Este metodo elimina el cultivo si ya se quedo sin vida
     */
    public void muerte2()
    {
        if(vidaCul.getValue() == 0)
        {
            Nivel2 aux = new Nivel2();
            aux.removeObject(this);
        }
    }
    
    /**
     * Este metodo elimina el cultivo si ya se quedo sin vida
     */
    public void muerte3()
    {
        if(vidaCul.getValue() == 0)
        {
            Nivel3 aux = new Nivel3();
            aux.removeObject(this);
        }
    }
}
