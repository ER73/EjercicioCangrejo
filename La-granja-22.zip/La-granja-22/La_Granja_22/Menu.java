import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nivel3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    private Ayuda ayu;
    private Creditos cred;
    private Jugar  jueg;
    private Records reco;
    /**
     * Constructor for objects of class Nivel3.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 380, 1); 
        ayu= new Ayuda();
        cred= new Creditos();
        jueg= new Jugar();
        reco = new Records();
        addObject(jueg,100,350);
        addObject(ayu,250,350);
        addObject(cred,400,350);
        addObject(reco,550,350);
    }
}
