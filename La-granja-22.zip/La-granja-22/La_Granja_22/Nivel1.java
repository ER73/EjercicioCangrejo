import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel1 extends World
{
    private Counter bMuertos;
    
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Nivel1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        bMuertos = new Counter();
        bMuertos.setValue(0);
        Greenfoot.setWorld(new Menu());
    }
    
    public void act()
    {
           creaBichos();
           aparecePuntos();
           apareceVida();
           sigNivel();
    }
    
    /**
     * Funcion para incrementar el contador de bichos muertos cuando uno muere
     */
    public void bichosMuertos()
    {
        bMuertos.setValue(bMuertos.getValue()+1);
    }
    
    /**
     * Este metodo crea bichos en un tiempo y espacio aleatorio
     */
    public void creaBichos()
    {
        if(Greenfoot.getRandomNumber(300) == 33)
        {
            addObject(new Bicho1(), Greenfoot.getRandomNumber(600),
                                  Greenfoot.getRandomNumber(400));
        }
    }
    
    /**
     * Funcion para cambiar de mundo cuando se mata al numero adecuado de bichos
     */
    public void sigNivel()
    {
        if(bMuertos.getValue() == 15)
        {
            Greenfoot.setWorld(new Nivel2());
        }
    }
    
    public void prepare()
    {
        Cultivo cultivo = new Cultivo();
        addObject(cultivo,66,192);
        Cultivo cultivo2 = new Cultivo();
        addObject(cultivo2,219,200);
        Cultivo cultivo3 = new Cultivo();
        addObject(cultivo3,68,117);
        Cultivo cultivo4 = new Cultivo();
        addObject(cultivo4,226,119);
        Cultivo cultivo5 = new Cultivo();
        addObject(cultivo5,368,124);
        Cultivo cultivo6 = new Cultivo();
        addObject(cultivo6,366,211);
        Cultivo cultivo7 = new Cultivo();
        addObject(cultivo7,504,129);
        Cultivo cultivo8 = new Cultivo();
        addObject(cultivo8,484,74);
        cultivo3.setLocation(66,41);
        cultivo4.setLocation(219,43);
        cultivo5.setLocation(370,45);
        cultivo8.setLocation(536,44);
        cultivo5.setLocation(375,43);
        cultivo4.setLocation(219,39);
        cultivo7.setLocation(537,161);
        cultivo6.setLocation(374,162);
        cultivo2.setLocation(212,161);
        cultivo.setLocation(58,161);
        Cultivo cultivo9 = new Cultivo();
        addObject(cultivo9,504,262);
        Cultivo cultivo10 = new Cultivo();
        addObject(cultivo10,352,344);
        Cultivo cultivo11 = new Cultivo();
        addObject(cultivo11,444,319);
        Cultivo cultivo12 = new Cultivo();
        addObject(cultivo12,337,273);
        cultivo12.setLocation(57,286);
        cultivo11.setLocation(209,282);
        cultivo10.setLocation(372,285);
        cultivo9.setLocation(541,286);
    }
    
    /**
     * Este metodo crea items que dan puntos aleatoriamente.
     */
    public void aparecePuntos()
    {
       if(Greenfoot.getRandomNumber(1000) == 20)
       {
           addObject(new Itempuntos(), getWidth(), 240);
       } 
    }
    
    /**
     * Este metodo crea items que dan vida aleatoriamete.
     */
    public void apareceVida()
    {
       if(Greenfoot.getRandomNumber(5000) == 20)
       {
           addObject(new Itemvida(), getWidth(), 240);
       } 
    }
}
