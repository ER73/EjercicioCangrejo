import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nido here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nido extends Actor
{
    /**
     * Act - do whatever the Nido wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        creaBichos();
    }
    
    /**
     * Este metodo crea bichos en un tiempo aleatorio cuando el nido aparece
     */
    public void creaBichos()
    {
        Nivel3 aux = new Nivel3();
        if(Greenfoot.getRandomNumber(300) == 33)
        {
            aux.addObject(new Bicho1(), this.getX(), this.getY());
        }
        if(Greenfoot.getRandomNumber(300) == 44)
        {
            aux.addObject(new Bicho2(), this.getX(), this.getY());
        }
        if(Greenfoot.getRandomNumber(300) == 55)
        {
            aux.addObject(new Bicho3(), this.getX(), this.getY());
        }
    }
}
